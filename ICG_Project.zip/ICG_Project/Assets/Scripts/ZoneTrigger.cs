using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ZoneTrigger : MonoBehaviour
{
    [Tooltip("2 = Ambient, 3 = Lambert, 4 = Specular")]
    public int lightingMode = 1;
    public TextMeshProUGUI text;

    private LightingController lightingController;

    void Start()
    {
        lightingController = FindObjectOfType<LightingController>();//get the lighting controller script
        lightingController.enabled = false;//deactivate it, make sure it won't change before we reach the trigger.
        text.enabled = false ;//tip text
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && lightingController != null)
        {
            //enable toggle and text when we hit the trigger.
            lightingController.enabled = true;
            text.enabled = true ;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player") && lightingController != null)
        {
            //disable all and set material to the original.
            text.enabled = false;
            lightingController.SetMode(1);
            lightingController.enabled = false;
        }
    }
}
