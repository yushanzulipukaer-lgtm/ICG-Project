﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zone3Platforms : MonoBehaviour
{

    [Header("Movement Settings")]
    public float floatAmplitude = 0.5f;  // How high it moves up and down
    public float floatSpeed = 1.5f;      // How fast it moves up and down
    public float rotationSpeed = 30f;    // How fast it rotates (degrees/sec)

    private Vector3 startPos;

    void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        // 1️⃣ Calculate vertical floating motion
        float yOffset = Mathf.Sin(Time.time * floatSpeed) * floatAmplitude;

        // 2️⃣ Apply up-down motion
        transform.position = startPos + new Vector3(0, yOffset, 0);

        // 3️⃣ Add continuous rotation around Y-axis
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime, Space.World);
    }
}
