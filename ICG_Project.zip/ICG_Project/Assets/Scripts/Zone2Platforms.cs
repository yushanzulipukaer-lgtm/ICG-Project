﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zone2Platforms : MonoBehaviour
{
    public float moveDistance = 5f;
    public float moveSpeed = 2f;

    private Vector3 startPos;
    private float direction;

    void Start()
    {
        startPos = transform.position;

        direction = Random.value > 0.5f ? 1f : -1f;
    }

    void Update()
    {
        // Move back and forth
        transform.position = startPos + new Vector3(0, Mathf.PingPong(Time.time * moveSpeed, moveDistance) * direction - (moveDistance / 2f * direction), 0);
    }
}
