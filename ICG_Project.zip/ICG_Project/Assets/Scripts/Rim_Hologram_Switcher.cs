﻿using UnityEngine;

public class Rim_Hologram_Switcher : MonoBehaviour
{
    public Material rimLight;
    public Material hologram;

    private Renderer rend;
    private bool usingRL = true;

    void Start()
    {
        rend = GetComponent<Renderer>();

        if (rend != null && rimLight != null)
        {
            rend.material = rimLight;
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            usingRL = !usingRL;

            if (usingRL)
            {
                rend.material = rimLight;
            }
            else
            {
                rend.material = hologram;
            }
        }
    }

}
