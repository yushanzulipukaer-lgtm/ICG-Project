﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zone3Platforms : MonoBehaviour
{

    [Header("Movement Settings")]
    public float floatAmplitude = 0.5f;
    public float floatSpeed = 1.5f;
    public float rotationSpeed = 30f; 

    private Vector3 startPos;

    void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        // calculate vertical floating motion
        float yOffset = Mathf.Sin(Time.time * floatSpeed) * floatAmplitude;

        // apply up-down motion
        transform.position = startPos + new Vector3(0, yOffset, 0);

        // add continuous rotation around Y-axis
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime, Space.World);
    }
}
