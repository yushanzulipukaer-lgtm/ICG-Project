﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zone2Platforms : MonoBehaviour
{
    public float moveDistance = 5f;
    public float moveSpeed = 2f;

    private Vector3 startPos;
    private float direction;

    void Start()
    {
        startPos = transform.position;

        direction = Random.value > 0.5f ? 1f : -1f;
    }

    void Update()
    {
        // Move up and down
        transform.position = startPos + new Vector3(0, Mathf.Sin(Time.time * moveSpeed) * moveSpeed, 0);
    }
}
