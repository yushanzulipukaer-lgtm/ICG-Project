﻿using UnityEngine;

public class FootStepAudio : MonoBehaviour
{
    public AudioSource audioSource;

    public AudioClip grassClip;
    public AudioClip rockClip;

    public float stepInterval = 0.4f;   // 两步之间的间隔

    private AudioClip currentClip;      
    private float timer;

    public CharacterController controller;

    private void Update()
    {
        Vector3 horizontalVelocity = new Vector3(controller.velocity.x, 0, controller.velocity.z);
        float speed = horizontalVelocity.magnitude;

        if (speed > 0.1f && currentClip != null)
        {
            timer -= Time.deltaTime;

            if (timer <= 0f)
            {
                audioSource.PlayOneShot(currentClip);
                timer = stepInterval;
            }
        }
        else
        {
            timer = 0f;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        switch (other.tag)
        {
            case "GrassArea":
                currentClip = grassClip;
                break;

            case "FloatingRocks":
                currentClip = rockClip;
                break;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        currentClip = null;
    }
}
