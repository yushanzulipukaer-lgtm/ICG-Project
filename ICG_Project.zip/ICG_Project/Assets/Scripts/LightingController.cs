using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightingController : MonoBehaviour
{
    public Material illuminationMaterial;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) SetMode(1);
        if (Input.GetKeyDown(KeyCode.Alpha2)) SetMode(2);
        if (Input.GetKeyDown(KeyCode.Alpha3)) SetMode(3);
        if (Input.GetKeyDown(KeyCode.Alpha4)) SetMode(4);
    }
    public void SetMode(int mode)
    {
        
        if (illuminationMaterial == null) return;
        illuminationMaterial.SetFloat("_Mode", mode);// using this function to set the mode.
    }
}
