using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ZoneTrigger2 : MonoBehaviour
{
    public TextMeshProUGUI text;
    private LUTToggle LUTToggle;
    // Start is called before the first frame update
    void Start()
    {
        LUTToggle = FindObjectOfType<LUTToggle>();
        LUTToggle.enabled = false;
        text.enabled = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Player"))
        {
            text.enabled = true;
            LUTToggle.enabled = true;

        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            text.enabled = false;
            LUTToggle.enabled = false;
        }
    }
}
