using UnityEngine;

public class LUTToggle : MonoBehaviour
{
    public Material lutMaterial;
    private bool enabledLUT = false;

    void Start()
    {
        if (lutMaterial != null)
            lutMaterial.SetFloat("_Contribution", 0f);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.L) && lutMaterial != null)
        {
            enabledLUT = !enabledLUT;
            lutMaterial.SetFloat("_Contribution", enabledLUT ? 1f : 0f);
            Debug.Log(enabledLUT ? "color correction is ON" : "color correction is OFF");
        }
    }
}
