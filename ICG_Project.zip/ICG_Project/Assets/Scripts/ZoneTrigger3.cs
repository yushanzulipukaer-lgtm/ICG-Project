using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;

public class ZoneTrigger3 : MonoBehaviour
{
    public TextMeshProUGUI text;
    public GameObject endText;
    private Rim_Hologram_Switcher rim_Hologram_Switcher;
    // Start is called before the first frame update
    void Start()
    {
        rim_Hologram_Switcher = FindObjectOfType<Rim_Hologram_Switcher>();
        text.enabled = false;
        endText.SetActive(false);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            text.enabled = true;
            endText.SetActive(true);
            rim_Hologram_Switcher.enabled = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            text.enabled = false;
            rim_Hologram_Switcher.enabled = false;
        }
    }
}
