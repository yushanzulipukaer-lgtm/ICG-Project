using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VisionDeviceToggle : MonoBehaviour
{
    public GameObject deviceScreen;
    public KeyCode toggleKey = KeyCode.V;
    void Start()
    {
        deviceScreen.SetActive(false);
    }
    void Update()
    {
        if (Input.GetKeyDown(toggleKey))
        {
            deviceScreen.SetActive(!deviceScreen.activeSelf);
        }
    }
}

