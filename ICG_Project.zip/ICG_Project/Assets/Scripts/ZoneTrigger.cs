using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ZoneTrigger : MonoBehaviour
{
    [Tooltip("2 = Ambient, 3 = Lambert, 4 = Specular")]
    public int lightingMode = 1;
    public TextMeshProUGUI text;

    private LightingController lightingController;

    void Start()
    {
        lightingController = FindObjectOfType<LightingController>();
        lightingController.enabled = false;
        text.enabled = false ;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && lightingController != null)
        {
            lightingController.enabled = true;
            text.enabled = true ;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player") && lightingController != null)
        {
            text.enabled = false;
            lightingController.SetMode(1);
            lightingController.enabled = false;
        }
    }
}
