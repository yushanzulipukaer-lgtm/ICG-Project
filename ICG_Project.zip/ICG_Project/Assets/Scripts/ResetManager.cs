using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetManager : MonoBehaviour
{
    public Transform startPoint; // get the initial respawn position
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            //The CharacterController should be shut down first, in order to tranfer.
            //Because CharacterController can not make sure if the new position is safe(not in the wall or in the air,etc),
            //so it will just override the new one with the old one.
            var controller = other.GetComponent<CharacterController>();
            if (controller != null) controller.enabled = false;

            other.transform.position = startPoint.position;

            if (controller != null) controller.enabled = true;
        }

    }
}
