using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RHTrigger : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Player"))
        {
            Rim_Hologram_Switcher rhSwitcher = FindObjectOfType<Rim_Hologram_Switcher>();
            rhSwitcher.enabled = true;
        }
    }
}
