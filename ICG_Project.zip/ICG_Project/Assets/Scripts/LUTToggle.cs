using UnityEngine;

public class LUTToggle : MonoBehaviour
{
    public Material lutMaterial;         // ָ�� Renderer Feature �õ�ͬһ�ݲ���
    public Texture2D lutTexture;         // ��� LUT ��ͼ
    private bool enabledLUT = false;

    void Start()
    {
        if (lutMaterial != null && lutTexture != null)
        {
            lutMaterial.SetTexture("_LUT", lutTexture);
            lutMaterial.SetFloat("_Contribution", 0f); 
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.L) && lutMaterial != null)
        {
            enabledLUT = !enabledLUT;
            lutMaterial.SetFloat("_Contribution", enabledLUT ? 1f : 0f);
            if(enabledLUT)
            {
                Debug.Log("coller correction is on");
            }
            else
            {
                Debug.Log("color correction is off");
            }
        }
    }
}
