﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextureToggle : MonoBehaviour
{
    public Material whiteMaterial; //default material

    private MeshRenderer[] renderers;
    private Material[][] originalMaterials;   //saving every textures(materials)
    private bool isWhite = false;

    void Start()
    {
        //get all the mesh renderers
        renderers = FindObjectsOfType<MeshRenderer>();

        //save all materials in the array
        originalMaterials = new Material[renderers.Length][];
        for (int i = 0; i < renderers.Length; i++)
        {
            originalMaterials[i] = renderers[i].materials;
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            ToggleMaterials();
        }
    }

    void ToggleMaterials()
    {
        isWhite = !isWhite;

        for (int i = 0; i < renderers.Length; i++)
        {
            if (isWhite)
            {
                //swtich all textures(materials) to default material
                Material[] whiteArray = new Material[originalMaterials[i].Length];
                for (int j = 0; j < whiteArray.Length; j++)
                    whiteArray[j] = whiteMaterial;

                renderers[i].materials = whiteArray;
            }
            else
            {
                //switch back
                renderers[i].materials = originalMaterials[i];
            }
        }
    }
}
