using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZoneTransitions : MonoBehaviour
{
    public Transform checkPoint;
    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Player"))
        {
            //using  FindObjectOfType<>() to get ResetManager script more easily.
            ResetManager resetManager = FindObjectOfType<ResetManager>();
            resetManager.startPoint = checkPoint;
        }

    }
}
