using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class LUTRendererFeature : ScriptableRendererFeature
{
    [System.Serializable]
    public class Settings
    {
        public Material lutMaterial;
        [Range(0, 1)] public float contribution = 1.0f;
    }

    public Settings settings = new Settings();

    class LUTPass : ScriptableRenderPass
    {
        private Material lutMaterial;
        private int tempTargetID = Shader.PropertyToID("_TempLUTTex");

        public LUTPass(Material mat)
        {
            lutMaterial = mat;
            renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if (lutMaterial == null)
                return;

            // ��ȡ����� RenderTarget��ע�⣺ֻ���������ȡ��
            var source = renderingData.cameraData.renderer.cameraColorTarget;

            CommandBuffer cmd = CommandBufferPool.Get("LUT Pass");

            RenderTextureDescriptor desc = renderingData.cameraData.cameraTargetDescriptor;
            desc.depthBufferBits = 0;
            cmd.GetTemporaryRT(tempTargetID, desc);

            // ��һ�� Blit �� ����Ļ��ɫ��������ʱRT + Ӧ�� LUT
            Blit(cmd, source, tempTargetID, lutMaterial, 0);

            // �ڶ��� Blit �� �� LUT �����������д����Ļ
            Blit(cmd, tempTargetID, source);

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }
    }

    LUTPass pass;

    public override void Create()
    {
        pass = new LUTPass(settings.lutMaterial);
    }

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (settings.lutMaterial == null)
            return;

        // ֻ�ڹ���������ܣ�����Ӱ�� UI
        if (renderingData.cameraData.isSceneViewCamera ||
            renderingData.cameraData.isPreviewCamera)
            return;

        renderer.EnqueuePass(pass);
    }
}
